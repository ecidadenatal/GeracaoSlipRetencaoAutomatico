drop table plugins.retencaoreceitaslip;
drop sequence plugins.retencaoreceitaslip_sequencial_seq;

drop table plugins.retencaotiporecgeraslip;
drop sequence plugins.retencaotiporecgeraslip_sequencial_seq;
